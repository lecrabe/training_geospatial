### Q1 -> Afficher les 30 premiers �l�ments du tableau df
head(df,30)
### Q2 ->  Afficher le nombre de points effectu�s par chaque op�rateur
table(df$operator)
### Q3 -> Afficher la somme de tous les points valid�s
nrow(df)
### Q4 -> Afficher les noms des codes possibles dans la carte
levels(as.factor(df$ref_class))
### Q5 -> Afficher le nombre de points issus de la carte avec le code "route" (map_class)
nrow(df[df$map_class == "route",])
table(df$map_class)["route"]
### Q6 -> Afficher le nombre de points avec le code "Fm" (ref_class) trouv�s par l'op�rateur "manual"
nrow(df[df$ref_class == "Fm" & df$operator == "manual",])
table(df$operator,df$ref_class)["manual","Fm"]
### Q7 -> Cr�er une copie de df appel�e my_df
my_df <- df
### Q8 -> Dans my_df, remplacer le nom de l'op�rateur "manual" par "CNIAF_visuel"
my_df[my_df$operator == "manual",]$operator <- "CNIAF_visuel"
table(my_df$operator)
### Q9a  -> Dans my_df, remplacer les codes (ref_class et map_class) "Fp", "Fm", "Fs" par "Foret"
my_df[substr(my_df$map_class,1,1) == "F",]$map_class <- "Foret"

### Q9b -> Dans my_df, remplacer les codes (ref_class et map_class) "Pp", "Pm", "Ps" et "route" par "Perte"
### Q9c -> remplacer les codes (ref_class et map_class) "NF", "Eau" par "Non-Foret"
my_df[substr(my_df$map_class,1,1) == "P",]$map_class <- "Perte"
my_df[my_df$map_class == "route",]$map_class <- "Perte"
my_df[my_df$map_class == "NF",]$map_class <- "Non-Foret"
my_df[my_df$map_class == "Eau",]$map_class <- "Non-Foret"

### Q10 -> Faire la meme chose avec les codes "ref_class" 

my_df[substr(my_df$ref_class,1,1) == "F",]$ref_class <- "Foret"
my_df[substr(my_df$ref_class,1,1) == "P",]$ref_class <- "Perte"
my_df[my_df$ref_class == "route",]$ref_class <- "Perte"
my_df[my_df$ref_class == "NF",]$ref_class <- "Non-Foret"
my_df[my_df$ref_class == "Eau",]$ref_class <- "Non-Foret"

### Q11 -> Afficher la matrice de confusion des classes aggr�g�es
table(my_df$ref_class,my_df$map_class)
