# Q1 -> Lire le fichier raster UTCATF sous une variable nomm�e "mon_raster" 
mon_raster <- raster("../data/raster_utcatf.tif")

# Q2 -> Extraire un sous-raster spatial pour la zone 14 � 16 degr�s Est et 0 � 1 degr�s Nord, nommer le "sub_raster"
sub_raster <- crop(mon_raster,extent(14,16,0,1))

# Q3 -> G�n�rer une grille de 500 points sur clip appel�e "ma_grille" (NB: conserver les coordonn�es)
# nb: faire en sorte que la grille soit sous format data.frame
ma_grille <- as.data.frame(sampleRandom(sub_raster,500,xy=TRUE))

# Q4 -> Renommer les colonnes de "ma_grille" avec les valeurs "x_coord", "y_coord" et "value". Ajouter une colonne avec un identifiant "id" unique
names(ma_grille) <- c("x_coord","y_coord","value")
ma_grille$id<-row(ma_grille)[,1]

# Q5 -> Afficher la distribution des points pour chaque classe
table(ma_grille$value)

# Q6 -> Extraire de "ma_grille" un jeu de 50 points al�atoires parmi la classe For�t Mar�cageuse. le nommer "pts_FM" 
# nb: avec la fonction "sample" utiliser une quelconque colonne 
pts_FM <- ma_grille[sample(ma_grille[ma_grille$value==13,]$id,50),]

# Q7 -> Extraire de "sub_raster" les pixels avec de l'eau en tant que data.frame, les nommer "df_rast_eaU". Ajouter une colonne avec un identifiant "id" unique
df_rast_eau <- data.frame(
  rasterToPoints(sub_raster,
                 fun=function(rast){rast==4}))

df_rast_eau$id<-row(df_rast_eau)[,1]

# Q8 -> Extraire de "df_rast_eau" un jeu de 50 points al�atoires, le nommer "pts_Eau"
pts_Eau <- df_rast_eau[
  sample(df_rast_eau$id,50)
  ,]

# Q9 -> Cr�er un graphique vide de la taille de "sub_raster", avec les labels "longitude" en abscisse et "latitude" en ordonn�e
plot(ma_grille$x,ma_grille$y,
     type="n",xlab="longitude",ylab="latitude")

# Q10 -> Afficher "sub_raster" en fond de graphe, les points de ma_grille (en noir), les points pts_FM en vert et les points pts_eau en bleu
rasterImage(as.raster(sub_raster),
            xmin(sub_raster),ymin(sub_raster),
            xmax(sub_raster),ymax(sub_raster))

points(ma_grille$x,ma_grille$y)
points(pts_FM$x,pts_FM$y,col="green",pch=19)
points(pts_Eau$x,pts_Eau$y,col="blue",pch=19)

