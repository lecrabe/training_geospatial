# Q1 -> Lire le fichier shapefile "Congo_departement_geo.shp" sous une variable nomm�e "mon_vecteur" 
mon_vecteur <- readOGR(dsn="../data",layer="congo_departement_geo")

# Q2 -> Afficher le shapefile du Congo et faire ressortir la Sangha en rouge
plot(mon_vecteur,col = "lightgrey")
plot(mon_vecteur[mon_vecteur$NOM_PR_FEC=="SANGHA", ], col = "red", add = TRUE)

# Q3 -> Reprojeter les vecteur en UTM (mon_utm)
mon_utm <- spTransform(mon_vecteur, CRS("+init=epsg:32633"))

# Q4 -> Calculer les surfaces des polygones dans une colonne appel�e superficie
mon_utm$superficie <- gArea(mon_utm,byid=T)

# Q5 -> Afficher la table des attributs
mon_utm@data

# Q6 -> Lire le fichier shapefile "points_NFI.shp" sous une variable nomm�e "mes_points" et projeter en UTM
mes_points <- readOGR(dsn="../data",layer="points_NFI")
mes_points <- spTransform(mes_points, CRS("+init=epsg:32633"))


# Q7 -> Extraire les points IFN dans la Likouala (pts_likouala)
pts_likouala <- mes_points[
  mon_utm[mon_utm$NOM_PR_FEC=="LIKOUALA",],]

# Q8 -> Faire un shapefile Likouala+Sangha de deux mani�res diff�rentes
union <- gUnion(mon_utm[
  mon_utm$NOM_PR_FEC=="LIKOUALA",],
  mon_utm[mon_utm$NOM_PR_FEC=="SANGHA",])

extrait <- mon_utm[mon_utm$NOM_PR_FEC=="LIKOUALA" | 
                     mon_utm$NOM_PR_FEC=="SANGHA",]

plot(union)
plot(extrait)
