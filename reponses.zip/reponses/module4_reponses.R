# Q1 -> Lire les fichiers : 
# "congo_departement_geo.shp" sous une variable nomm�e  "DPT"
# "gfc_aggrege.tif"           sous une variable nomm�e  "GFC"
# "NFI_data_biomasse.csv"     sous un variable nomm�e   "IFN"

DPT <- readOGR(dsn="../data",layer="congo_departement_geo")
GFC <- raster("../data/gfc_aggrege.tif")
IFN  <- read.csv("../data/NFI_data_biomasse.csv")

# Q2 -> Cr�er un nouveau raster appel� "tc_class" des classes de couverture arbor�e 
# classe 1 : TC 0-30  
# classe 2 : TC 30-70 
# classe 3 : TC 70-100
tc_class <- (GFC<30) + (GFC>=30 & GFC < 70)*2 + (GFC > 70)*3

# Q3 -> Extraire la valeur de couverture arbor�e pour chaque point de l'IFN
### l'ins�rer comme nouvelle colonne ("couverture") dans le fichier table
IFN$couverture <- extract(GFC,IFN[,c(1:2)])

# Q4 -> Afficher le graphique biomasse VS couverture
plot(IFN$biomass_tha,IFN$couverture,xlab="Biomasse t/ha",ylab="% Couv. Arbor�e")

# Q5 -> Afficher les moyennes et quantiles de couverture arboree par classe de biomasse
graphics::boxplot(IFN$couverture ~ IFN$class_biomass)

# Q6 -> Cr�er un vecteur de 1 � 4
liste <- 1:4
# Q7 -> Cr�er une fonction qui affiche le nombre de ligne du fichier biomasse pour une modalit� donn�e
comptage <- function(x){nrow(IFN[IFN$class_biomass==x,])}

# Q8 -> Appliquer la fonction � la liste 1:4.
# Quelle est la fonction globale que vous avez recr�� ?
sapply(liste,comptage)
table(IFN$class_biomass)

# Q9 -> Cr�er un raster de la couverture arbor�e � ~1km de r�solution (facteur=4)
gfc_1km <- aggregate(GFC,fact=4,fun=mean)

# Q10 -> Cr�er un raster des d�partements du pays � la m�me r�solution
tmp<-raster(resolution=res(gfc_1km),ext=extent(gfc_1km),crs=projection(gfc_1km))
dpt_rast <- rasterize(x=DPT,y=tmp,field="CDE_PR_FEC",background=0,fun='first',update=T)
plot(dpt_rast)

# Q11 -> Chercher la fonction "zonal" et Calculer la moyenne, le min et le max de couverture arbor�e par d�partement
x1 <- zonal(gfc_1km,dpt_rast,fun='mean')
x2 <- zonal(gfc_1km,dpt_rast,fun='max')
x3 <- zonal(gfc_1km,dpt_rast,fun='min')
gfc_dpt <- merge(x1,x2)
gfc_dpt <- merge(gfc_dpt,x3)
(gfc_dpt <- merge(DPT@data[,c(3,4)],gfc_dpt,by.x=1,by.y=1))

